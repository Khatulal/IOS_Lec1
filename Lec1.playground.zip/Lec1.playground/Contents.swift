//: Playground - noun: a place where people can play

//import UIKit
////UI controls(Views), animations:
//
////UI kit imports a framework called Foundation: Defines the basic types like Int and so on.
//
//
//
////variables are defined using the var keyword.
////Strings can be defined with ""
//var str = "Hello, playground"
////swift uses type inference. it knows the type since we used ""
//
//
////constant
//let pi = 3.14 //Double
//
//
////pi = pi + 1 //does not compile
//
//print(pi)
//
//
//var name = "Moses" //variable
//let moe:String = "Moe" //constant
//
//var x:Int = 10 //long way of doing things: Type annotation
//
//var z:String? = nil //nil, the syntax z:String? is called optional String
//
//var userName = "" //normal way of declaring variables.

//coffee and cookie
let bill:Double = 20

//let's play:
//define a constant name TipAmount: 0.1 -> Use type annotation for practice

//calculate the tipAmount

//print the tip Amount
let tipPercent:Double = 0.1
let tipAmount = bill * tipPercent
print(tipAmount)


//Type casting:
let x = Int("3")

//similar to new in JAVA:
//new instance of the class UIButton
let vc = UInt()

//Type casting:
//we have a String -> we want to convert it to an Int
let str = "3" //String
//Convert str to an Int:
let intValue = Int(str)
print(intValue)

//swift will force us to use if statements to test for nil!

let tipPct = 0.1
let billA = 20
let timAmount = tipPct * Double(billA) //similar to Double.valueOf (in JAVA)

print("The result: " + String(tipAmount))



let apples = 3
let oranges = 5

let appleSummary = "I have " + String(apples) + "apples"

//The Swift way:
//String interpolation:
let apSum = "I have \(apples) Apples"

//use spaces before and after operators!
let fruitSum = apples + oranges

//use String interpolation to include a name in a greeting:
let name:String = "MyName"
print("Hello, \(name)")

//let tableName = "Students"
//let sql = "SELECT * FROM \(tableName)"


let tableName = "Entries"
let colID = "Title"
let colTitle = "Title"
let colSubTitle = "SubTitle"

//CREATE TABLE tableName(colID INTEGER PRIMARY KEY, colTitle TEXT, )

//singe line Strings:
let SQL = "CREATE TABLE \(tableName)(\(colID) INTEGER PRIMARY KEY, \(colTitle) TEXT, \(colSubTitle) TEXT)"

let BETTER_SQL = """
    CREATE TABLE \(tableName)(
        \(colID) INTEGER PRIMARY KEY,
        \(colTitle) TEXT,
        \(colSubTitle) TEXT
    )
"""


//Rederence: where to study? look at wwdc

//Flow control - loops, if, switch
//arrays and lists and dictionaries(Bundle, HashMap, ...), ...

//Arrays act as lists and are efficient

// or var a = [1, 2, 3]
var a:[Int] = [1, 2, 3]

var arr = ["Hey", "Aloha", "Ahalan"]
print(arr[0])
arr.append("Shalom")


var names:[String] = []

//fori in JAVA
//from 0 to 10 (inclusive)
for i in 0...10{
    print(i)
}

//from 0 to 10 (exclusive)
//0...9
for x in 0..<10{
    print(x)
}


var fib:[Int] = [1, 1, 2, 3, 5, 8, 13]
for myX in fib{
    print(myX)
}

//var sum = 0
//for curr in fib{
//    sum += curr
//}

var mult = 1
for curr in fib{
    mult *= curr
}

var arrTargil = [Int]()
for i in 1...10{
    arrTargil.append(i)
}

print(arrTargil)

//flow control: for, while, if
var money = 4000
var phone:String?

if money < 100 {
    print("No phone for you...")
    phone = "None"
} else if money < 1000 {
    phone = "Chinese Android"
} else if money <= 3900 {
    phone = "Branded Android"
} else {
    phone = "iPhone"
    print("Now you don't have money")
}



var breakTime = 45 //Minutes
//like do {} while in JAVA
repeat {
    print("Study")
    breakTime -= 1
} while breakTime > 0

//1)find all the even numbers butween 0 and 100
//2)find the sum of the numbers between 0 and 100 which are can be divided by both 3 and 7
//3)print all the odd numbers between 39 and 150 and print how many they are

//4)Haxor Challenge:
let base = 2
let power = 8
var yourAns = 1

//answer 1
var arrEven:[Int] = []
for i in 0...100 {
    if i % 2 == 0 {
        arrEven.append(i)
    }
}

//answer 2
var sum = 0
for i in 0...100 {
    if (i % 3 == 0) && (i % 7 == 0) {
        sum += i
    }
}

//answer 3
var count = 0
for i in 39...150 {
    if i % 2 == 1 {
        print(i)
        count += 1
    }
}
print(count)

//answer 4
//use loops to get the ans
for _ in 1...power {
    yourAns *= base
}
print(yourAns)
